// Quando o popup solicitar dados, retorna link e thumbnail
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg === 'getVideoData') {
    const link  = window.location.href;
    const meta  = document.querySelector('meta[property="og:image"]');
    const thumb = meta ? meta.content : '';
    sendResponse({ link, thumb });
  }
});
