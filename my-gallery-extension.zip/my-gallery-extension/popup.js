// popup.js

// inicializa Firebase
const firebaseConfig = { 
       apiKey: "AIzaSyBWJ97Q-BbC8MX1JCTOxiY5c-DxnkUKKsc",
       authDomain: "minha-galeria-de-videos.firebaseapp.com",
       projectId: "minha-galeria-de-videos",
       storageBucket: "minha-galeria-de-videos.firebasestorage.app",
       messagingSenderId: "322400887452",
       appId: "1:322400887452:web:4797684e09620facb7c359" };
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

// resto do seu código…


firebase.initializeApp(firebaseConfig );
const db = firebase.firestore();

document.addEventListener('DOMContentLoaded', () => {
  // Pede dados ao content script
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    chrome.tabs.sendMessage(tabs[0].id, 'getVideoData', data => {
      document.getElementById('video-link').value = data.link;
      document.getElementById('thumb-url').value = data.thumb;
    });
  });

  document.getElementById('add').addEventListener('click', async () => {
    const link = document.getElementById('video-link').value;
    const thumb = document.getElementById('thumb-url').value;
    const desc = document.getElementById('description').value;
    // chama seu Firestore
    await db.collection('videos').add({ videoLink: link, thumbUrl: thumb, desc, timestamp: firebase.firestore.FieldValue.serverTimestamp() });
    window.close();
  });
});
